# Notificador de partidos de Sporting Cristal

Este proyecto envía un correo con los próximos partidos de Sporting Cristal.

## Pasos:
1. Crea la base de datos y la tabla credenciales (ver más abajo).
2. Pon tus credenciales y API Key.
3. Ejecuta: python src/main.py
