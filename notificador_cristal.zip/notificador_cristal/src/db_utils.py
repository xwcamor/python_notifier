def obtener_credenciales():
    # Retorna el correo y la contraseña de aplicación de Gmail directamente (NO uses tu contraseña normal)
    return 'cruzmaster18full@gmail.com', 'yddkppskupcsmqrz'