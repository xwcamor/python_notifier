import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

EMAIL_DESTINO = 'jeferjorge164@gmail.com'  # Cambia por tu correo de destino

def formatear_html(partidos):
    html = f"""
    <h2 style="color:#1A3AC2;">Próximos partidos de Sporting Cristal</h2>
    <table border="1" cellpadding="5" style="border-collapse:collapse;font-family:Arial;">
        <tr style="background-color:#1A3AC2; color:white;">
            <th>Fecha</th>
            <th>Hora</th>
            <th>Local</th>
            <th>Visitante</th>
            <th>Liga</th>
        </tr>
    """
    if partidos:
        for p in partidos:
            html += f"""
            <tr>
                <td>{p['fecha']}</td>
                <td>{p['hora']}</td>
                <td>{p['local']}</td>
                <td>{p['visitante']}</td>
                <td>{p['liga']}</td>
            </tr>
            """
    else:
        html += """
        <tr>
            <td colspan="5" style="text-align:center; color:gray; background:#e8eaf6;">
                No hay partidos próximos registrados.
            </td>
        </tr>
        """
    html += "</table>"
    return html


def enviar_correo(html, email_origen, email_contrasena):
    msg = MIMEMultipart('alternative')
    msg['Subject'] = "Próximos partidos de Sporting Cristal"
    msg['From'] = email_origen
    msg['To'] = EMAIL_DESTINO
    part = MIMEText(html, 'html')
    msg.attach(part)
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(email_origen, email_contrasena)
        smtp.sendmail(email_origen, EMAIL_DESTINO.split(','), msg.as_string())