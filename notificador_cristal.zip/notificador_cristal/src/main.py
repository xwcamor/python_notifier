from db_utils import obtener_credenciales
from futbol_api import obtener_partidos
from email_utils import formatear_html, enviar_correo

if __name__ == "__main__":
    # Obtén el correo y la contraseña de aplicación desde db_utils.py
    email_origen, email_contrasena = obtener_credenciales()

    # Consulta los próximos partidos desde futbol_api.py
    partidos = obtener_partidos()

    # Formatea la información en HTML
    html = formatear_html(partidos)

    # Envía el correo con la información
    enviar_correo(html, email_origen, email_contrasena)

    print("Correo enviado con éxito.")