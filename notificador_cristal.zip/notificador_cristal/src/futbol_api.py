import requests

API_KEY = 'c383c8e816cd9c314d1dd2e11f8ee8d0'  # Tu API Key

def obtener_partidos():
    url = "https://v3.football.api-sports.io/fixtures"
    params = {
        "team": "76",  # ID Sporting Cristal
        "next": 5
    }
    headers = {
        "x-apisports-key": API_KEY
    }
    response = requests.get(url, headers=headers, params=params)
    data = response.json()
    partidos = []
    for item in data["response"]:
        fixture = item["fixture"]
        teams = item["teams"]
        league = item["league"]
        partidos.append({
            "fecha": fixture["date"][:10],
            "hora": fixture["date"][11:16],
            "local": teams["home"]["name"],
            "visitante": teams["away"]["name"],
            "liga": league["name"],
        })
    return partidos

